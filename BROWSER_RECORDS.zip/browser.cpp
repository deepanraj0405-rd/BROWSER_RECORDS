#include <iostream>
using namespace std;

#define MAX 10

class Browser {
    string history[MAX];
    int top;

public:
    Browser() {
        top = -1;
    }

    // Visit a webpage
    void visit(string page) {
        if (top == MAX - 1) {
            cout << "History is full!" << endl;
            return;
        }

        history[++top] = page;
    }

    // Press Back
    void back() {
        if (top == -1) {
            cout << "No history available!" << endl;
            return;
        }

        cout << "Removed: " << history[top] << endl;
        top--;
    }

    // Display current top page
    void displayTop() {
        if (top == -1) {
            cout << "History is empty!" << endl;
        } else {
            cout << "Current top page: " << history[top] << endl;
        }
    }
};

int main() {
    Browser browser;

    // Browser history
    browser.visit("Google.com");
    browser.visit("YouTube.com");
    browser.visit("ABCSC.com");
    browser.visit("Facebook.com");

    cout << "Pressing Back twice:\n";

    // Back 1
    browser.back();

    // Back 2
    browser.back();

    // Display current top
    browser.displayTop();

    return 0;
}
